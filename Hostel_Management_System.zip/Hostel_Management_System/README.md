# Hostel-Management-System
A system built for hostel room and mess allocation and management. Implemented using HTML, JavaScript, PHP and MySql database

# Features
 1. Log in as student or Hostel Manager
 2. As student pay fees, apply for rooms / mess
 3. As Hostel Manager look at all the room / mess applications and allocate them
 4. Vacate Students from a room / mess
 5. View a list of all allocated students





